<h1>
Polling project in laravel for begginer and intermediate 
</h1>
